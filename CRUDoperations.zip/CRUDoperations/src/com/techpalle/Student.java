package com.techpalle;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Student 
{
	public void create()
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/j2eeproject","root","admin");
			Statement s=con.createStatement();
			s.executeUpdate("create table studentdata(id int ,name varchar(50),city varchar(50))");
			s.close();
			con.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void read()
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/j2eeproject","root","admin");
			Statement s=con.createStatement();
			ResultSet rs=s.executeQuery("select * from studentdata");
			while(rs.next())
			{
				int id=rs.getInt(1);
				String name=rs.getString(2);
				String city=rs.getString(3);
				System.out.println(id+""+name+""+city);
			}
			s.close();
			con.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void update(int id,String name,String city)
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/j2eeproject","root","admin");
			PreparedStatement ps=con.prepareStatement("insert into studentdata values(?,?,?)");
			ps.setInt(1, id);
			ps.setString(2, name);
			ps.setString(3, city);
			ps.executeUpdate();
			ps.close();
			con.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	public void delete(int id)
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/j2eeproject","root","admin");
			PreparedStatement ps=con.prepareStatement("delete from studentdata where id=?");
			ps.setInt(1, id);
			ps.executeUpdate();
			ps.close();
			con.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
