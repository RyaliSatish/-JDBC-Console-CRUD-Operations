package com.techpalle;

public class Main {

	public static void main(String[] args) {
		Student s=new Student();
		//s.create();
		//s.read();
		//s.update(2, "king", "heaven");
		s.delete(1);

	}

}
