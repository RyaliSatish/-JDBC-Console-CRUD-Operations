/**
 * 
 */
/**
 * 
 */
module CRUDoperations {
	requires java.sql;
}